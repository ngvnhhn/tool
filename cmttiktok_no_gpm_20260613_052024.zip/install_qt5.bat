@echo off
echo Installing PyQt5 dependencies...
pip install PyQt5==5.15.10
pip install PyQt5-Qt5==5.15.2
pip install PyQt5-sip==12.13.0
pip install PyQtWebEngine==5.15.6
echo Installation completed!
pause
