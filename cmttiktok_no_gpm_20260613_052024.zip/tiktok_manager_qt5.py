import sys
import json
import csv
import time
import os
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
try:
    from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEngineProfile, QWebEnginePage
    WEBENGINE_AVAILABLE = True
except Exception:
    WEBENGINE_AVAILABLE = False

class ModernButton(QPushButton):
    def __init__(self, text, color="primary"):
        super().__init__(text)
        self.color = color
        self.setFixedHeight(40)
        self.setCursor(Qt.PointingHandCursor)
        
class ModernLineEdit(QLineEdit):
    def __init__(self, placeholder=""):
        super().__init__()
        self.setPlaceholderText(placeholder)
        self.setFixedHeight(40)
        
class ModernTextEdit(QTextEdit):
    def __init__(self):
        super().__init__()
        self.setFixedHeight(120)

class StatusWorker(QObject):
    status_update = pyqtSignal(str)
    
    def log(self, message):
        timestamp = time.strftime('%H:%M:%S')
        self.status_update.emit(f"[{timestamp}] {message}")

class AccountDialog(QDialog):
    def __init__(self, parent=None, account=None):
        super().__init__(parent)
        self.account = account
        self.setWindowTitle("Thêm tài khoản" if account is None else "Sửa tài khoản")
        self.setFixedSize(600, 500)
        self.setModal(True)
        
        self.setup_ui()
        
        if account:
            self.load_account_data()
            
    def setup_ui(self):
        layout = QVBoxLayout()
        
        # Form
        form_layout = QFormLayout()
        
        self.username_edit = ModernLineEdit("Nhập username TikTok")
        self.password_edit = ModernLineEdit("Nhập password TikTok")
        self.password_edit.setEchoMode(QLineEdit.Password)
        self.email_edit = ModernLineEdit("Nhập email (tùy chọn)")
        self.email_password_edit = ModernLineEdit("Nhập password email (tùy chọn)")
        self.email_password_edit.setEchoMode(QLineEdit.Password)
        self.proxy_edit = ModernLineEdit("ip:port:user:pass")
        
        self.cookie_edit = QTextEdit()
        self.cookie_edit.setFixedHeight(100)
        self.cookie_edit.setPlaceholderText("Nhập cookie JSON (tùy chọn)")
        
        form_layout.addRow("Username TikTok:", self.username_edit)
        form_layout.addRow("Password TikTok:", self.password_edit)
        form_layout.addRow("Email:", self.email_edit)
        form_layout.addRow("Password Email:", self.email_password_edit)
        form_layout.addRow("Proxy:", self.proxy_edit)
        form_layout.addRow("Cookie:", self.cookie_edit)
        
        layout.addLayout(form_layout)
        
        # Buttons
        button_layout = QHBoxLayout()
        
        save_btn = ModernButton("Lưu", "primary")
        cancel_btn = ModernButton("Hủy", "secondary")
        
        save_btn.clicked.connect(self.save_account)
        cancel_btn.clicked.connect(self.reject)
        
        button_layout.addWidget(save_btn)
        button_layout.addWidget(cancel_btn)
        
        layout.addLayout(button_layout)
        
        self.setLayout(layout)
        
    def load_account_data(self):
        self.username_edit.setText(self.account.get('username', ''))
        self.password_edit.setText(self.account.get('password', ''))
        self.email_edit.setText(self.account.get('email', ''))
        self.email_password_edit.setText(self.account.get('email_password', ''))
        self.proxy_edit.setText(self.account.get('proxy', ''))
        self.cookie_edit.setPlainText(self.account.get('cookie', ''))
        
    def save_account(self):
        if not self.username_edit.text().strip():
            QMessageBox.warning(self, "Lỗi", "Username không được để trống")
            return
            
        self.account_data = {
            'username': self.username_edit.text().strip(),
            'password': self.password_edit.text().strip(),
            'email': self.email_edit.text().strip(),
            'email_password': self.email_password_edit.text().strip(),
            'proxy': self.proxy_edit.text().strip(),
            'cookie': self.cookie_edit.toPlainText().strip()
        }
        
        self.accept()

class TikTokAccountManager(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("TikTok Account Manager & Like Bot")
        self.setGeometry(100, 100, 1400, 900)
        self.app_dir = os.path.dirname(os.path.abspath(__file__))
        self.accounts_file = os.path.join(self.app_dir, 'accounts.json')
        
        # Data
        self.accounts = []
        self.running_tasks = {}
        self.active_threads = []
        self.browser_tabs = {}
        self.browser_profiles_dir = os.path.join(self.app_dir, 'browser_profiles')
        os.makedirs(self.browser_profiles_dir, exist_ok=True)
        self.pending_tasks = []  # Hàng đợi task chờ xử lý
        
        # Status worker
        self.status_worker = StatusWorker()
        self.status_worker.status_update.connect(self.log_status)
        
        self.setup_ui()
        self.apply_styles()
        self.load_accounts()
        
    def closeEvent(self, event):
        """Handle application close event"""
        self.close_all_browser_tabs()
        self.cleanup_threads()
        event.accept()
        
    def cleanup_threads(self):
        """Properly cleanup all running threads"""
        for task_id, task_info in list(self.running_tasks.items()):
            thread = task_info['thread']
            if thread.isRunning():
                thread.quit()
                thread.wait(3000)  # Wait up to 3 seconds
                if thread.isRunning():
                    thread.terminate()
                    thread.wait(1000)
        
        # Clean up any remaining threads
        for thread in self.active_threads:
            if thread.isRunning():
                thread.quit()
                thread.wait(3000)
                if thread.isRunning():
                    thread.terminate()
                    thread.wait(1000)
        
        self.running_tasks.clear()
        self.active_threads.clear()
        
    def setup_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        main_layout = QVBoxLayout()
        central_widget.setLayout(main_layout)
        
        # Header
        header = QLabel("TikTok Account Manager & Like Bot")
        header.setObjectName("header")
        header.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(header)
        
        # Tab widget
        self.tab_widget = QTabWidget()
        self.tab_widget.setObjectName("mainTabs")
        
        # Account management tab
        self.setup_account_tab()

        # Browser tab
        self.setup_browser_tab()
        
        # Like bot tab
        self.setup_bot_tab()
        
        main_layout.addWidget(self.tab_widget)
        
    def setup_account_tab(self):
        account_widget = QWidget()
        layout = QVBoxLayout()
        
        # Toolbar
        toolbar = QHBoxLayout()
        
        add_btn = ModernButton("➕ Thêm tài khoản", "primary")
        edit_btn = ModernButton("✏️ Sửa tài khoản", "secondary")
        delete_btn = ModernButton("🗑️ Xóa tài khoản", "danger")
        select_all_btn = ModernButton("Chọn tất cả", "success")
        clear_all_btn = ModernButton("Bỏ chọn", "secondary")
        open_selected_btn = ModernButton("Mở acc đã chọn", "info")
        import_btn = ModernButton("📥 Import CSV", "info")
        export_btn = ModernButton("📤 Export CSV", "info")
        
        add_btn.clicked.connect(self.add_account)
        edit_btn.clicked.connect(self.edit_account)
        delete_btn.clicked.connect(self.delete_account)
        select_all_btn.clicked.connect(lambda: self.set_all_accounts_checked(True))
        clear_all_btn.clicked.connect(lambda: self.set_all_accounts_checked(False))
        open_selected_btn.clicked.connect(self.open_checked_accounts)
        import_btn.clicked.connect(self.import_csv)
        export_btn.clicked.connect(self.export_csv)
        
        toolbar.addWidget(add_btn)
        toolbar.addWidget(edit_btn)
        toolbar.addWidget(delete_btn)
        toolbar.addWidget(select_all_btn)
        toolbar.addWidget(clear_all_btn)
        toolbar.addWidget(open_selected_btn)
        toolbar.addStretch()
        toolbar.addWidget(import_btn)
        toolbar.addWidget(export_btn)
        
        layout.addLayout(toolbar)
        
        # Account table
        self.account_table = QTableWidget()
        self.account_table.setColumnCount(10)
        self.account_table.setHorizontalHeaderLabels([
            "Chọn", "ID", "Username", "Password", "Email", "Email Pass", "Cookie", "Proxy", "Trạng thái", "Việc đang làm"
        ])
        
        # Set column widths
        header = self.account_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.Stretch)
        header.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(4, QHeaderView.Stretch)
        header.setSectionResizeMode(5, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(6, QHeaderView.Stretch)
        header.setSectionResizeMode(7, QHeaderView.Stretch)
        header.setSectionResizeMode(8, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(9, QHeaderView.Stretch)
        
        self.account_table.setAlternatingRowColors(True)
        self.account_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.account_table.itemChanged.connect(self.account_check_changed)
        
        layout.addWidget(self.account_table)
        
        account_widget.setLayout(layout)
        self.tab_widget.addTab(account_widget, "👥 Quản lý tài khoản")

    def setup_browser_tab(self):
        browser_widget = QWidget()
        layout = QVBoxLayout()

        if not WEBENGINE_AVAILABLE:
            warning = QLabel(
                "Chưa cài PyQtWebEngine nên chưa mở được trình duyệt trong tool.\n"
                "Hãy chạy install_qt5.bat rồi mở lại tool."
            )
            warning.setAlignment(Qt.AlignCenter)
            warning.setStyleSheet("font-size: 16px; color: #dc3545; padding: 30px;")
            layout.addWidget(warning)
            browser_widget.setLayout(layout)
            self.tab_widget.addTab(browser_widget, "🌐 Trình duyệt acc")
            return

        toolbar = QHBoxLayout()

        self.browser_account_combo = QComboBox()
        self.browser_account_combo.setMinimumWidth(260)

        open_btn = ModernButton("Mở acc", "primary")
        close_btn = ModernButton("Đóng tab", "secondary")
        close_all_btn = ModernButton("Đóng tất cả", "danger")

        self.browser_url_edit = ModernLineEdit("https://www.tiktok.com")
        self.browser_url_edit.setText("https://www.tiktok.com")
        go_btn = ModernButton("Đi tới URL", "info")

        open_btn.clicked.connect(self.open_selected_account_browser)
        close_btn.clicked.connect(self.close_current_browser_tab)
        close_all_btn.clicked.connect(self.close_all_browser_tabs)
        go_btn.clicked.connect(self.browser_go_to_url)

        toolbar.addWidget(QLabel("Account:"))
        toolbar.addWidget(self.browser_account_combo)
        toolbar.addWidget(open_btn)
        toolbar.addSpacing(20)
        toolbar.addWidget(self.browser_url_edit)
        toolbar.addWidget(go_btn)
        toolbar.addWidget(close_btn)
        toolbar.addWidget(close_all_btn)

        self.browser_tab_widget = QTabWidget()
        self.browser_tab_widget.setTabsClosable(True)
        self.browser_tab_widget.tabCloseRequested.connect(self.close_browser_tab)

        layout.addLayout(toolbar)
        layout.addWidget(self.browser_tab_widget)

        browser_widget.setLayout(layout)
        self.tab_widget.addTab(browser_widget, "🌐 Trình duyệt acc")
        self.update_browser_account_combo()

    def update_browser_account_combo(self):
        if not hasattr(self, 'browser_account_combo'):
            return

        current_id = self.browser_account_combo.currentData()
        self.browser_account_combo.blockSignals(True)
        self.browser_account_combo.clear()

        for account in self.accounts:
            account_id = str(account.get('id', '')).strip()
            username = account.get('username', '').strip() or account_id
            self.browser_account_combo.addItem(username, account_id)

        if current_id:
            index = self.browser_account_combo.findData(current_id)
            if index >= 0:
                self.browser_account_combo.setCurrentIndex(index)

        self.browser_account_combo.blockSignals(False)

    def open_selected_account_browser(self):
        if not WEBENGINE_AVAILABLE:
            QMessageBox.warning(self, "Thiếu thư viện", "Vui lòng chạy install_qt5.bat để cài PyQtWebEngine")
            return

        account_id = self.browser_account_combo.currentData()
        if not account_id:
            QMessageBox.warning(self, "Cảnh báo", "Vui lòng thêm hoặc chọn account")
            return

        account = next((acc for acc in self.accounts if str(acc.get('id')) == str(account_id)), None)
        if not account:
            QMessageBox.warning(self, "Cảnh báo", "Không tìm thấy account đã chọn")
            return

        url = self.browser_url_edit.text().strip() or "https://www.tiktok.com"
        self.open_account_browser(account, url)

    def open_account_browser(self, account, url="https://www.tiktok.com"):
        account_id = str(account.get('id'))
        username = account.get('username', account_id)

        if account_id in self.browser_tabs:
            tab_info = self.browser_tabs[account_id]
            index = self.browser_tab_widget.indexOf(tab_info['view'])
            if index >= 0:
                self.browser_tab_widget.setCurrentIndex(index)
                tab_info['view'].load(QUrl(url))
                return

        profile_dir = os.path.join(self.browser_profiles_dir, account_id)
        cache_dir = os.path.join(profile_dir, 'cache')
        os.makedirs(cache_dir, exist_ok=True)

        profile = QWebEngineProfile(f"profile_{account_id}", self)
        profile.setPersistentStoragePath(profile_dir)
        profile.setCachePath(cache_dir)
        profile.setPersistentCookiesPolicy(QWebEngineProfile.ForcePersistentCookies)

        page = QWebEnginePage(profile, self)
        view = QWebEngineView()
        view.setPage(page)
        view.load(QUrl(url))

        index = self.browser_tab_widget.addTab(view, username)
        self.browser_tab_widget.setCurrentIndex(index)

        self.browser_tabs[account_id] = {
            'account': account,
            'profile': profile,
            'page': page,
            'view': view
        }

    def browser_go_to_url(self):
        view = self.browser_tab_widget.currentWidget() if hasattr(self, 'browser_tab_widget') else None
        if not view:
            return
        url = self.browser_url_edit.text().strip()
        if not url:
            return
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        view.load(QUrl(url))

    def close_current_browser_tab(self):
        if not hasattr(self, 'browser_tab_widget'):
            return
        index = self.browser_tab_widget.currentIndex()
        if index >= 0:
            self.close_browser_tab(index)

    def close_browser_tab(self, index):
        if index < 0:
            return
        view = self.browser_tab_widget.widget(index)
        account_id_to_remove = None

        for account_id, tab_info in self.browser_tabs.items():
            if tab_info.get('view') is view:
                account_id_to_remove = account_id
                break

        self.browser_tab_widget.removeTab(index)
        if account_id_to_remove:
            tab_info = self.browser_tabs.pop(account_id_to_remove, {})
            view = tab_info.get('view')
            if view:
                view.deleteLater()

    def close_all_browser_tabs(self):
        if not hasattr(self, 'browser_tab_widget'):
            return
        while self.browser_tab_widget.count() > 0:
            self.close_browser_tab(0)
        
    def setup_bot_tab(self):
        bot_widget = QWidget()
        layout = QVBoxLayout()
        
        # Input section
        input_group = QGroupBox("🎯 Cấu hình tim comment")
        input_layout = QVBoxLayout()
        
        # Settings row
        settings_layout = QHBoxLayout()
        
        # Số luồng
        thread_label = QLabel("Số luồng:")
        self.thread_spinbox = QSpinBox()
        self.thread_spinbox.setMinimum(1)
        self.thread_spinbox.setMaximum(20)
        self.thread_spinbox.setValue(3)
        self.thread_spinbox.setFixedWidth(80)
        
        # Số account mỗi link
        acc_per_link_label = QLabel("Số account/link:")
        self.acc_per_link_spinbox = QSpinBox()
        self.acc_per_link_spinbox.setMinimum(1)
        self.acc_per_link_spinbox.setMaximum(50)
        self.acc_per_link_spinbox.setValue(1)
        self.acc_per_link_spinbox.setFixedWidth(80)
        
        settings_layout.addWidget(thread_label)
        settings_layout.addWidget(self.thread_spinbox)
        settings_layout.addSpacing(20)
        settings_layout.addWidget(acc_per_link_label)
        settings_layout.addWidget(self.acc_per_link_spinbox)
        settings_layout.addStretch()
        
        # Task input
        task_label = QLabel("Danh sách task tim comment:")
        task_label.setObjectName("sectionLabel")
        
        # Task format info
        self.task_format_label = QLabel("Format: linkbaiviet|target_username|so_comment_can_tim")
        self.task_format_label.setObjectName("formatLabel")
        
        info_label = QLabel("💡 Ví dụ: Nếu nhập số 5, tool sẽ tìm và tim 5 comment của user đó trong video")
        info_label.setObjectName("infoLabel")
        info_label.setStyleSheet("color: #6c757d; font-size: 11px; font-style: italic;")
        
        self.task_text = QTextEdit()
        self.task_text.setFixedHeight(150)
        self.task_text.setPlaceholderText("https://www.tiktok.com/@zuzjeebabi_/video/7593697893756849424|candydayne0_0|5\nhttps://www.tiktok.com/@user/video/456|target_user|3")
        
        input_layout.addLayout(settings_layout)
        input_layout.addWidget(task_label)
        input_layout.addWidget(self.task_format_label)
        input_layout.addWidget(info_label)
        input_layout.addWidget(self.task_text)
        
        # Control buttons
        control_layout = QHBoxLayout()
        
        start_btn = ModernButton("🚀 Bắt đầu tim comment", "success")
        stop_btn = ModernButton("⏹️ Dừng tất cả", "danger")
        refresh_btn = ModernButton("🔄 Làm mới", "info")
        
        start_btn.clicked.connect(self.start_like_bot)
        stop_btn.clicked.connect(self.stop_all_tasks)
        refresh_btn.clicked.connect(self.refresh_status)
        
        control_layout.addWidget(start_btn)
        control_layout.addWidget(stop_btn)
        control_layout.addWidget(refresh_btn)
        control_layout.addStretch()
        
        input_layout.addLayout(control_layout)
        input_group.setLayout(input_layout)
        
        layout.addWidget(input_group)
        
        # Status section
        status_group = QGroupBox("📊 Trạng thái hoạt động")
        status_layout = QVBoxLayout()
        
        self.status_text = QTextEdit()
        self.status_text.setReadOnly(True)
        self.status_text.setObjectName("statusText")
        
        status_layout.addWidget(self.status_text)
        status_group.setLayout(status_layout)
        
        layout.addWidget(status_group)
        
        bot_widget.setLayout(layout)
        self.tab_widget.addTab(bot_widget, "❤️ Tim comment TikTok")
        
    def apply_styles(self):
        style = """
        QMainWindow {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #f8f9fa, stop:1 #e9ecef);
        }
        
        #header {
            font-size: 28px;
            font-weight: bold;
            color: #2c3e50;
            padding: 20px;
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                stop:0 #667eea, stop:1 #764ba2);
            color: white;
            border-radius: 10px;
            margin: 10px;
        }
        
        #mainTabs {
            background: white;
            border-radius: 10px;
            margin: 10px;
        }
        
        QTabWidget::pane {
            border: 1px solid #dee2e6;
            border-radius: 10px;
            background: white;
        }
        
        QTabWidget::tab-bar {
            alignment: center;
        }
        
        QTabBar::tab {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #f8f9fa, stop:1 #e9ecef);
            border: 1px solid #dee2e6;
            padding: 12px 24px;
            margin-right: 2px;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
            font-weight: bold;
            font-size: 14px;
        }
        
        QTabBar::tab:selected {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #667eea, stop:1 #764ba2);
            color: white;
        }
        
        QTabBar::tab:hover:!selected {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #e3f2fd, stop:1 #bbdefb);
        }
        
        QPushButton {
            border: none;
            border-radius: 8px;
            padding: 12px 24px;
            font-weight: bold;
            font-size: 14px;
            min-width: 120px;
        }
        
        QPushButton[color="primary"] {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #667eea, stop:1 #764ba2);
            color: white;
        }
        
        QPushButton[color="primary"]:hover {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #5a6fd8, stop:1 #6a4190);
        }
        
        QPushButton[color="secondary"] {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #6c757d, stop:1 #495057);
            color: white;
        }
        
        QPushButton[color="secondary"]:hover {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #5a6268, stop:1 #3d4449);
        }
        
        QPushButton[color="success"] {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #28a745, stop:1 #20c997);
            color: white;
        }
        
        QPushButton[color="success"]:hover {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #218838, stop:1 #1ca085);
        }
        
        QPushButton[color="danger"] {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #dc3545, stop:1 #e83e8c);
            color: white;
        }
        
        QPushButton[color="danger"]:hover {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #c82333, stop:1 #d91a7a);
        }
        
        QPushButton[color="info"] {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #17a2b8, stop:1 #6f42c1);
            color: white;
        }
        
        QPushButton[color="info"]:hover {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #138496, stop:1 #5a32a3);
        }
        
        QLineEdit {
            border: 2px solid #e9ecef;
            border-radius: 8px;
            padding: 12px;
            font-size: 14px;
            background: white;
        }
        
        QLineEdit:focus {
            border-color: #667eea;
            background: #f8f9ff;
        }
        
        QTextEdit {
            border: 2px solid #e9ecef;
            border-radius: 8px;
            padding: 12px;
            font-size: 14px;
            background: white;
            font-family: 'Consolas', 'Monaco', monospace;
        }
        
        QTextEdit:focus {
            border-color: #667eea;
            background: #f8f9ff;
        }
        
        #statusText {
            background: #1e1e1e;
            color: #00ff00;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 12px;
        }
        
        QTableWidget {
            border: 1px solid #dee2e6;
            border-radius: 8px;
            background: white;
            gridline-color: #e9ecef;
            font-size: 13px;
        }
        
        QTableWidget::item {
            padding: 8px;
            border-bottom: 1px solid #f1f3f4;
        }
        
        QTableWidget::item:selected {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #e3f2fd, stop:1 #bbdefb);
            color: #1976d2;
        }
        
        QHeaderView::section {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #f8f9fa, stop:1 #e9ecef);
            padding: 12px;
            border: none;
            border-right: 1px solid #dee2e6;
            font-weight: bold;
            color: #495057;
        }
        
        QGroupBox {
            font-weight: bold;
            font-size: 16px;
            color: #495057;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            margin: 10px 0;
            padding-top: 20px;
        }
        
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 20px;
            padding: 0 10px 0 10px;
            background: white;
        }
        
        #sectionLabel {
            font-weight: bold;
            color: #495057;
            font-size: 14px;
            margin-bottom: 8px;
        }
        
        #formatLabel {
            font-style: italic;
            color: #6c757d;
            font-size: 12px;
            margin-bottom: 5px;
        }
        """
        
        self.setStyleSheet(style)
        
    def log_status(self, message):
        self.status_text.append(message)
        self.status_text.ensureCursorVisible()
        
    def add_account(self):
        dialog = AccountDialog(self)
        if dialog.exec_() == QDialog.Accepted:
            account_data = dialog.account_data
            account_data['id'] = self.new_account_id()
            account_data['status'] = 'Chưa sử dụng'
            account_data['current_task'] = ''
            account_data['selected'] = True
            
            self.accounts.append(account_data)
            self.save_accounts()
            self.refresh_account_table()
            
    def edit_account(self):
        current_row = self.account_table.currentRow()
        if current_row < 0:
            QMessageBox.warning(self, "Cảnh báo", "Vui lòng chọn tài khoản để sửa")
            return
            
        account = self.accounts[current_row]
        dialog = AccountDialog(self, account)
        
        if dialog.exec_() == QDialog.Accepted:
            account_data = dialog.account_data
            account_data['id'] = account['id']
            account_data['status'] = account.get('status', 'Chưa sử dụng')
            account_data['current_task'] = account.get('current_task', '')
            account_data['selected'] = account.get('selected', True)
            
            self.accounts[current_row] = account_data
            self.save_accounts()
            self.refresh_account_table()
            
    def delete_account(self):
        checked_accounts = self.get_checked_accounts()

        if checked_accounts:
            accounts_to_delete = checked_accounts
        else:
            current_row = self.account_table.currentRow()
            if current_row < 0:
                QMessageBox.warning(self, "Cảnh báo", "Vui lòng tích chọn hoặc chọn dòng tài khoản để xóa")
                return
            accounts_to_delete = [self.accounts[current_row]]

        reply = QMessageBox.question(
            self,
            "Xác nhận",
            f"Bạn có chắc muốn xóa {len(accounts_to_delete)} tài khoản đã chọn?",
            QMessageBox.Yes | QMessageBox.No
        )

        if reply != QMessageBox.Yes:
            return

        delete_ids = {str(account.get('id')) for account in accounts_to_delete}

        for account_id in list(delete_ids):
            tab_info = self.browser_tabs.get(account_id)
            if tab_info and hasattr(self, 'browser_tab_widget'):
                index = self.browser_tab_widget.indexOf(tab_info.get('view'))
                if index >= 0:
                    self.close_browser_tab(index)

        self.accounts = [
            account for account in self.accounts
            if str(account.get('id')) not in delete_ids
        ]
        self.save_accounts()
        self.refresh_account_table()
            
    def refresh_account_table(self):
        self.account_table.blockSignals(True)
        self.account_table.setRowCount(len(self.accounts))
        self.update_browser_account_combo()
        
        for i, account in enumerate(self.accounts):
            check_item = QTableWidgetItem()
            check_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsUserCheckable)
            check_item.setCheckState(Qt.Checked if account.get('selected', True) else Qt.Unchecked)
            check_item.setData(Qt.UserRole, account.get('id', ''))
            self.account_table.setItem(i, 0, check_item)

            self.account_table.setItem(i, 1, QTableWidgetItem(account.get('id', '')))
            self.account_table.setItem(i, 2, QTableWidgetItem(account.get('username', '')))
            self.account_table.setItem(i, 3, QTableWidgetItem('*' * len(account.get('password', ''))))
            self.account_table.setItem(i, 4, QTableWidgetItem(account.get('email', '')))
            self.account_table.setItem(i, 5, QTableWidgetItem('*' * len(account.get('email_password', ''))))
            
            cookie_text = account.get('cookie', '')
            cookie_display = cookie_text[:30] + '...' if len(cookie_text) > 30 else cookie_text
            self.account_table.setItem(i, 6, QTableWidgetItem(cookie_display))
            
            self.account_table.setItem(i, 7, QTableWidgetItem(account.get('proxy', '')))
            
            status_item = QTableWidgetItem(account.get('status', 'Chưa sử dụng'))
            if account.get('status') == 'Đang hoạt động':
                status_item.setBackground(QColor('#d4edda'))
                status_item.setForeground(QColor('#155724'))
            else:
                status_item.setBackground(QColor('#f8d7da'))
                status_item.setForeground(QColor('#721c24'))
            self.account_table.setItem(i, 8, status_item)
            
            self.account_table.setItem(i, 9, QTableWidgetItem(account.get('current_task', '')))

        self.account_table.blockSignals(False)

    def account_check_changed(self, item):
        if item.column() != 0:
            return
        row = item.row()
        if 0 <= row < len(self.accounts):
            self.accounts[row]['selected'] = item.checkState() == Qt.Checked
            self.save_accounts()

    def set_all_accounts_checked(self, checked):
        for account in self.accounts:
            account['selected'] = checked
        self.refresh_account_table()
        self.save_accounts()

    def get_checked_accounts(self):
        return [account for account in self.accounts if account.get('selected', True)]

    def open_checked_accounts(self):
        checked_accounts = self.get_checked_accounts()
        if not checked_accounts:
            QMessageBox.warning(self, "Cảnh báo", "Chưa tích chọn account nào")
            return
        if not WEBENGINE_AVAILABLE:
            QMessageBox.warning(self, "Thiếu thư viện", "Vui lòng chạy install_qt5.bat để cài PyQtWebEngine")
            return

        url = "https://www.tiktok.com"
        if hasattr(self, 'browser_url_edit'):
            url = self.browser_url_edit.text().strip() or url
        for account in checked_accounts:
            self.open_account_browser(account, url)
            
    def import_csv(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Chọn file CSV", "", "CSV files (*.csv)")
        
        if file_path:
            try:
                with open(file_path, 'r', encoding='utf-8') as file:
                    reader = csv.DictReader(file)
                    imported_count = 0
                    
                    for row in reader:
                        account = {
                            'id': str(int(time.time()) + imported_count),
                            'username': row.get('username', ''),
                            'password': row.get('password', ''),
                            'email': row.get('email', ''),
                            'email_password': row.get('email_password', ''),
                            'cookie': row.get('cookie', ''),
                            'proxy': row.get('proxy', ''),
                            'status': 'Chưa sử dụng',
                            'current_task': '',
                            'selected': True
                        }
                        self.accounts.append(account)
                        imported_count += 1
                        
                self.save_accounts()
                self.refresh_account_table()
                QMessageBox.information(self, "Thành công", f"Đã import {imported_count} tài khoản")
                
            except Exception as e:
                QMessageBox.critical(self, "Lỗi", f"Không thể import file: {str(e)}")
                
    def export_csv(self):
        file_path, _ = QFileDialog.getSaveFileName(self, "Lưu file CSV", "", "CSV files (*.csv)")
        
        if file_path:
            try:
                with open(file_path, 'w', newline='', encoding='utf-8') as file:
                    fieldnames = ['username', 'password', 'email', 'email_password', 'cookie', 'proxy', 'status', 'current_task']
                    writer = csv.DictWriter(file, fieldnames=fieldnames)
                    writer.writeheader()
                    
                    for account in self.accounts:
                        writer.writerow({
                            'username': account.get('username', ''),
                            'password': account.get('password', ''),
                            'email': account.get('email', ''),
                            'email_password': account.get('email_password', ''),
                            'cookie': account.get('cookie', ''),
                            'proxy': account.get('proxy', ''),
                            'status': account.get('status', ''),
                            'current_task': account.get('current_task', '')
                        })
                        
                QMessageBox.information(self, "Thành công", f"Đã export {len(self.accounts)} tài khoản")
                
            except Exception as e:
                QMessageBox.critical(self, "Lỗi", f"Không thể export file: {str(e)}")
                
    def start_like_bot(self):
        task_input = self.task_text.toPlainText().strip()
        if not task_input:
            QMessageBox.warning(self, "Cảnh báo", "Vui lòng nhập danh sách task")
            return
            
        # Đọc cấu hình
        max_threads = self.thread_spinbox.value()
        accounts_per_link = self.acc_per_link_spinbox.value()
        
        # Parse tasks với format: linkbaiviet|target_username|soluong
        tasks = []
        for line in task_input.split('\n'):
            line = line.strip()
            if not line:
                continue
                
            parts = line.split('|')
            if len(parts) >= 3:
                task = {
                    'url': parts[0].strip(),
                    'target_username': parts[1].strip(),
                    'count': int(parts[2].strip()) if parts[2].strip().isdigit() else 1,
                    'type': 'comment'
                }
                tasks.append(task)
        
        if not tasks:
            QMessageBox.warning(self, "Cảnh báo", "Không có task hợp lệ. Format: linkbaiviet|target_username|soluong")
            return
            
        # Tính tổng số task cần chạy (mỗi link x số account)
        total_tasks = len(tasks) * accounts_per_link
        
        # Kiểm tra số tài khoản khả dụng
        checked_accounts = self.get_checked_accounts()
        if not checked_accounts:
            QMessageBox.warning(self, "Cảnh báo", "Chưa tích chọn account nào để chạy")
            return

        available_accounts = [
            acc for acc in checked_accounts
            if acc.get('id') not in self.running_tasks
        ]
        
        if len(available_accounts) < total_tasks:
            reply = QMessageBox.question(
                self, 
                "Cảnh báo", 
                f"Cần {total_tasks} tài khoản ({len(tasks)} link x {accounts_per_link} acc/link) nhưng chỉ có {len(available_accounts)} tài khoản khả dụng.\n\nTiếp tục với số tài khoản hiện có?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply == QMessageBox.No:
                return
        
        # Log thông tin
        self.status_worker.log("=== MỞ VIDEO THEO ACCOUNT ĐÃ CHỌN ===")
        self.status_worker.log(f"Số link video: {len(tasks)}")
        self.status_worker.log(f"Số account/link: {accounts_per_link}")
        self.status_worker.log(f"Tổng task: {min(total_tasks, len(available_accounts))}")
        self.status_worker.log(f"Số tab mở tối đa theo cấu hình: {max_threads}")
        self.status_worker.log(f"================================")
        
        # Tạo danh sách tất cả các task (mỗi link x số account)
        all_tasks = []
        account_index = 0
        
        for task in tasks:
            for i in range(accounts_per_link):
                if account_index >= len(available_accounts):
                    break
                    
                account = available_accounts[account_index]
                account_index += 1
                
                all_tasks.append({
                    'account': account,
                    'task': task,
                    'task_number': i + 1
                })
            
            if account_index >= len(available_accounts):
                break
        
        self.open_tasks_in_internal_browser(all_tasks)
        
        self.refresh_account_table()

    def open_tasks_in_internal_browser(self, all_tasks):
        if not WEBENGINE_AVAILABLE:
            QMessageBox.warning(
                self,
                "Thiếu thư viện",
                "Vui lòng chạy install_qt5.bat để cài PyQtWebEngine"
            )
            return

        if not all_tasks:
            QMessageBox.warning(self, "Cảnh báo", "Không có task nào để mở")
            return

        opened_count = 0
        self.status_worker.log("=== MỞ TASK TRONG TRÌNH DUYỆT NỘI BỘ ===")

        for task_info in all_tasks:
            account = task_info['account']
            task = task_info['task']
            username = account.get('username', account.get('id', 'account'))

            account['status'] = 'Đang hoạt động'
            account['current_task'] = f"Mở video {task['url']} - tìm @{task['target_username']}"

            try:
                self.open_account_browser(account, task['url'])
                opened_count += 1
                self.status_worker.log(
                    f"[{username}] Đã mở video trong tab nội bộ; target @{task['target_username']}"
                )
            except Exception as exc:
                self.status_worker.log(f"[{username}] Không thể mở tab: {exc}")
            finally:
                account['status'] = 'Chưa sử dụng'
                account['current_task'] = ''

        self.refresh_account_table()
        self.save_accounts()
        self.tab_widget.setCurrentWidget(self.browser_tab_widget.parentWidget())
        self.status_worker.log(f"=== ĐÃ MỞ {opened_count}/{len(all_tasks)} TASK ===")
    

    def stop_all_tasks(self):
        """Close all internal browser tabs and reset account state."""
        self.status_worker.log("Đang đóng tất cả tab...")
        self.close_all_browser_tabs()
        self.pending_tasks.clear()
        self.running_tasks.clear()
        self.active_threads.clear()
        for account in self.accounts:
            account['status'] = 'Chưa sử dụng'
            account['current_task'] = ''
        self.refresh_account_table()
        self.save_accounts()
        self.status_worker.log("Đã đóng tất cả tab")
        
    def refresh_status(self):
        self.refresh_account_table()
        self.status_worker.log("Đã làm mới trạng thái")
        
    def load_accounts(self):
        try:
            with open(self.accounts_file, 'r', encoding='utf-8') as f:
                self.accounts = json.load(f)
        except FileNotFoundError:
            self.accounts = []
        except Exception as e:
            self.status_worker.log(f"Lỗi load accounts: {str(e)}")
            self.accounts = []

        seen_ids = set()
        for account in self.accounts:
            account_id = str(account.get('id', '')).strip()
            if not account_id or account_id in seen_ids:
                account['id'] = self.new_account_id(seen_ids)
                account_id = account['id']
            seen_ids.add(account_id)
            account['status'] = 'Chưa sử dụng'
            account['current_task'] = ''
            account.setdefault('selected', True)
            
        self.refresh_account_table()
        
    def save_accounts(self):
        try:
            with open(self.accounts_file, 'w', encoding='utf-8') as f:
                json.dump(self.accounts, f, ensure_ascii=False, indent=2)
        except Exception as e:
            self.status_worker.log(f"Lỗi save accounts: {str(e)}")

    def new_account_id(self, existing_ids=None):
        if existing_ids is None:
            existing_ids = {str(acc.get('id', '')) for acc in self.accounts}
        while True:
            account_id = str(time.time_ns())
            if account_id not in existing_ids:
                return account_id

def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    
    # Set application icon and properties
    app.setApplicationName("TikTok Account Manager")
    app.setApplicationVersion("2.0")
    app.setOrganizationName("TikTok Tools")
    
    window = TikTokAccountManager()
    window.show()
    
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
