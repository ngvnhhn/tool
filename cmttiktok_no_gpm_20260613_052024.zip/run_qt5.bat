@echo off
echo Starting TikTok Account Manager (Qt5 Version)...
python tiktok_manager_qt5.py
pause